<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\CRM\\App\\Providers\\CRMServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\CRM\\App\\Providers\\CRMServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);