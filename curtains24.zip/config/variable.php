<?php

return [

//	'date_format' => '',

	'currency' => '$',
	'currency_format' => 'prefix',
	'account_id' => 1,

];
