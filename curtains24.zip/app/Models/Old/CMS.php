<?php

namespace App\Models\Old;


use Illuminate\Database\Eloquent\Model;

class CMS extends Model
{
    //
	protected $guarded=[];
}
