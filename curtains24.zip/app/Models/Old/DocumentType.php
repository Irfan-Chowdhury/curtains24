<?php

namespace App\Models\Old;


use Illuminate\Database\Eloquent\Model;

class DocumentType extends Model
{
	protected $fillable = [
		'document_type'
	];
}