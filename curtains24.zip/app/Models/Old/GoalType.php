<?php

namespace App\Models\Old;


use Illuminate\Database\Eloquent\Model;

class GoalType extends Model
{
    protected $fillable = [
        'goal_type'
    ];
}
