<?php

namespace App\Models\Old;


use Illuminate\Database\Eloquent\Model;

class JobCategory extends Model
{
    //
	protected $guarded=[];

	public $timestamps = false;


}
