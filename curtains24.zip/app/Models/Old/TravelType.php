<?php

namespace App\Models\Old;

use Illuminate\Database\Eloquent\Model;

class TravelType extends Model
{
	protected $fillable = [
		'arrangement_type'
	];
}
