<?php

namespace App\Models\Old;


use Illuminate\Database\Eloquent\Model;

class Calendarable extends Model
{
    //
}
