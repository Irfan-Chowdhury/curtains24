<?php

namespace App\Services;

class ModuleService
{
    public function getModule()
    {
        return 'Module';
    }
}
